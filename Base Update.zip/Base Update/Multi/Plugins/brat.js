let handler = async (m, { conn, text, reply, prefix, command }) => {
  if (!text) return reply(`Ex: ${prefix + command} Aku Sayang Kamu`)
  const media = `https://api-yannrzy-vy.vercel.app/imagecreator/brat?apikey=freeapiyn&text=${text}`;

  conn.sendImageAsSticker(m.chat, media, m, {
    packname: "Sbrat2",
    author: "Kame"
  });
}

handler.help = ['sticker brat'];
handler.tags = ['sticker'];
handler.command = ["sbrat", "brat"];

module.exports = handler;
